# Ntfy

Upstream docs: https://docs.ntfy.sh/publish/

## URL Format

--8<-- "docs/services/ntfy/config.md"