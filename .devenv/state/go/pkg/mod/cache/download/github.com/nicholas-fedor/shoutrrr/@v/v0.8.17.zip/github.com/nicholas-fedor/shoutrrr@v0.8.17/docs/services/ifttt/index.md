# IFTTT

## URL Format

!!! info ""
    ifttt://__`key`__/?events=__`event1`__[,__`event2`__,...]&value1=__`value1`__&value2=__`value2`__&value3=__`value3`__

--8<-- "docs/services/ifttt/config.md"