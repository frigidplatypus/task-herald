# Logger

No configuration options are available for this service.

It simply emits notifications to the Shoutrrr log which is
configured by the consumer.